var searchData=
[
  ['vertexattribpointer_0',['vertexAttribPointer',['../d3/d8c/classce_1_1Shader.html#a37a795e8df58aae314a9c1bf9a713754',1,'ce::Shader::vertexAttribPointer(std::string attrib, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer)'],['../d3/d8c/classce_1_1Shader.html#ad1eb44f140951bbf800f550d9da78ebf',1,'ce::Shader::vertexAttribPointer(Attribute attrib, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer)']]]
];
