var searchData=
[
  ['nearclip_0',['nearClip',['../dd/d8a/classce_1_1Camera.html#af2477ba3e42e75ad46f833a4d36c48df',1,'ce::Camera']]],
  ['normal_1',['normal',['../d8/d43/structce_1_1Vertex.html#a70cbe82ca7789a6c98105c9feb6eb576',1,'ce::Vertex']]]
];
