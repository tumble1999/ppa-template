var searchData=
[
  ['vertex_0',['Vertex',['../d8/d43/structce_1_1Vertex.html',1,'ce']]]
];
