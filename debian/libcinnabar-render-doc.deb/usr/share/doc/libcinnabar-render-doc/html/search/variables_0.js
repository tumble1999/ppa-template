var searchData=
[
  ['ambient_0',['ambient',['../d3/d1a/structce_1_1MaterialFile.html#a81ce02d1594e0ec3805bd78a4bc700af',1,'ce::MaterialFile']]]
];
