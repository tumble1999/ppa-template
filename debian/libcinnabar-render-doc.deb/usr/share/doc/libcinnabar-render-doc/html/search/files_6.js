var searchData=
[
  ['vertex_2ehpp_0',['vertex.hpp',['../d1/d2d/vertex_8hpp.html',1,'']]]
];
