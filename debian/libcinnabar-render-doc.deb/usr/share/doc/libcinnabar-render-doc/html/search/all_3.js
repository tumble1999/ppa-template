var searchData=
[
  ['data_0',['data',['../dd/dc5/structce_1_1TextureFile.html#ae7a07de0a83b389249ac80836574a7c4',1,'ce::TextureFile']]],
  ['diffuse_1',['diffuse',['../d3/d1a/structce_1_1MaterialFile.html#a60416c61a25218410d8b0f30a1ec7b30',1,'ce::MaterialFile']]],
  ['diffusetex_2',['diffuseTex',['../d3/d1a/structce_1_1MaterialFile.html#adad4786c9d9adc02e60e4f204165d370',1,'ce::MaterialFile']]]
];
