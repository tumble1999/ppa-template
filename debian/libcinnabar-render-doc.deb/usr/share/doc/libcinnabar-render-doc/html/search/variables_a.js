var searchData=
[
  ['shader_0',['shader',['../d3/d1a/structce_1_1MaterialFile.html#a3d725a9e278d8b1ff4f7f3a892737037',1,'ce::MaterialFile']]],
  ['shader_5ffolder_1',['SHADER_FOLDER',['../d5/d4b/namespacece_1_1assetManager_1_1defaults.html#a801170978d8432f0aba0aa3e74306242',1,'ce::assetManager::defaults']]],
  ['shader_5fmissing_2',['SHADER_MISSING',['../d5/d4b/namespacece_1_1assetManager_1_1defaults.html#af981f4faaea1f3400d801f839d691cc7',1,'ce::assetManager::defaults']]],
  ['speclular_3',['speclular',['../d3/d1a/structce_1_1MaterialFile.html#a59200185cf65a6a0555da945a330b037',1,'ce::MaterialFile']]],
  ['speculartex_4',['specularTex',['../d3/d1a/structce_1_1MaterialFile.html#acfc4464aa606ae82c8ec3aaf4ee8ed8a',1,'ce::MaterialFile']]]
];
