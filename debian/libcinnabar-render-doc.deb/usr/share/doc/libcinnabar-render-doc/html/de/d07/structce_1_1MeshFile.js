var structce_1_1MeshFile =
[
    [ "indices", "de/d07/structce_1_1MeshFile.html#ab5cc21fb4bd4c3c0f1d07970105499ed", null ],
    [ "verts", "de/d07/structce_1_1MeshFile.html#a84abc5b19b7bcc6181eac97e4d4221bf", null ]
];