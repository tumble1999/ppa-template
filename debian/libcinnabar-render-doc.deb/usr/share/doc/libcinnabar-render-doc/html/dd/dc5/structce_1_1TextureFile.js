var structce_1_1TextureFile =
[
    [ "channelCount", "dd/dc5/structce_1_1TextureFile.html#aacc2aaa1cd408b97d65ffbfeb5be138f", null ],
    [ "data", "dd/dc5/structce_1_1TextureFile.html#ae7a07de0a83b389249ac80836574a7c4", null ],
    [ "height", "dd/dc5/structce_1_1TextureFile.html#a0e3f778c4efbcffa50a39e62e6920b1b", null ],
    [ "width", "dd/dc5/structce_1_1TextureFile.html#ae73c29779c66d80cfe390aaddef29c6b", null ]
];