var structce_1_1ShaderFile =
[
    [ "frag", "dd/df5/structce_1_1ShaderFile.html#ad306908dae4635f821053745f02dbf4b", null ],
    [ "geom", "dd/df5/structce_1_1ShaderFile.html#ae255b6271dff802810afd273f9435e02", null ],
    [ "vert", "dd/df5/structce_1_1ShaderFile.html#a6e83b8fe043cc88ffb1519cb0d068b4a", null ]
];