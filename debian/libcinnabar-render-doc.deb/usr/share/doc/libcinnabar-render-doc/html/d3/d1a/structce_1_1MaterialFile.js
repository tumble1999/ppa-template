var structce_1_1MaterialFile =
[
    [ "ambient", "d3/d1a/structce_1_1MaterialFile.html#a81ce02d1594e0ec3805bd78a4bc700af", null ],
    [ "diffuse", "d3/d1a/structce_1_1MaterialFile.html#a60416c61a25218410d8b0f30a1ec7b30", null ],
    [ "diffuseTex", "d3/d1a/structce_1_1MaterialFile.html#adad4786c9d9adc02e60e4f204165d370", null ],
    [ "shader", "d3/d1a/structce_1_1MaterialFile.html#a3d725a9e278d8b1ff4f7f3a892737037", null ],
    [ "speclular", "d3/d1a/structce_1_1MaterialFile.html#a59200185cf65a6a0555da945a330b037", null ],
    [ "specularTex", "d3/d1a/structce_1_1MaterialFile.html#acfc4464aa606ae82c8ec3aaf4ee8ed8a", null ]
];