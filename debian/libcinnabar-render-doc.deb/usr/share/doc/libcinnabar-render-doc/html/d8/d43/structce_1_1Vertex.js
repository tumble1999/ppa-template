var structce_1_1Vertex =
[
    [ "color", "d8/d43/structce_1_1Vertex.html#a7c815802a13a44d354c080c9b50054f7", null ],
    [ "normal", "d8/d43/structce_1_1Vertex.html#a70cbe82ca7789a6c98105c9feb6eb576", null ],
    [ "position", "d8/d43/structce_1_1Vertex.html#a594a061ebbac41aef7065ff51671b025", null ],
    [ "uv", "d8/d43/structce_1_1Vertex.html#a89f7a1e1edb2c9b4f160afcc25d2596a", null ]
];