var annotated_dup =
[
    [ "ce", "d2/dd6/namespacece.html", [
      [ "Camera", "dd/d8a/classce_1_1Camera.html", "dd/d8a/classce_1_1Camera" ],
      [ "Material", "d5/d2e/classce_1_1Material.html", "d5/d2e/classce_1_1Material" ],
      [ "MaterialFile", "d3/d1a/structce_1_1MaterialFile.html", "d3/d1a/structce_1_1MaterialFile" ],
      [ "Mesh", "d6/d6e/classce_1_1Mesh.html", "d6/d6e/classce_1_1Mesh" ],
      [ "MeshFile", "de/d07/structce_1_1MeshFile.html", "de/d07/structce_1_1MeshFile" ],
      [ "RenderEngine", "d2/df2/classce_1_1RenderEngine.html", "d2/df2/classce_1_1RenderEngine" ],
      [ "Shader", "d3/d8c/classce_1_1Shader.html", "d3/d8c/classce_1_1Shader" ],
      [ "ShaderFile", "dd/df5/structce_1_1ShaderFile.html", "dd/df5/structce_1_1ShaderFile" ],
      [ "Texture", "d2/de2/classce_1_1Texture.html", "d2/de2/classce_1_1Texture" ],
      [ "TextureFile", "dd/dc5/structce_1_1TextureFile.html", "dd/dc5/structce_1_1TextureFile" ],
      [ "Vertex", "d8/d43/structce_1_1Vertex.html", "d8/d43/structce_1_1Vertex" ],
      [ "Window", "dc/dee/classce_1_1Window.html", "dc/dee/classce_1_1Window" ]
    ] ]
];