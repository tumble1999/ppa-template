var asset__manager_8hpp =
[
    [ "getTextFile", "d6/d15/asset__manager_8hpp.html#ab7925c90ed44920dd6a7d68003b0f1d1", null ],
    [ "RESOURCE_FOLDER", "d6/d15/asset__manager_8hpp.html#abf032cb0799a97dce24d18ece6f59a05", null ]
];