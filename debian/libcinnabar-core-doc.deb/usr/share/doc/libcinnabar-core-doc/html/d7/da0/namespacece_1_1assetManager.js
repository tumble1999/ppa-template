var namespacece_1_1assetManager =
[
    [ "defaults", "d5/d4b/namespacece_1_1assetManager_1_1defaults.html", [
      [ "RESOURCE_FOLDER", "d5/d4b/namespacece_1_1assetManager_1_1defaults.html#abf032cb0799a97dce24d18ece6f59a05", null ]
    ] ],
    [ "getTextFile", "d7/da0/namespacece_1_1assetManager.html#ab7925c90ed44920dd6a7d68003b0f1d1", null ]
];