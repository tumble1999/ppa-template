var searchData=
[
  ['recalculate_0',['recalculate',['../df/d10/classce_1_1Time.html#a08cbdc5d98de66dcf4da54c3490083bb',1,'ce::Time']]],
  ['roll_1',['roll',['../d3/dfa/classce_1_1Transform.html#a1609c10bce7200c361aad9180c38c054',1,'ce::Transform']]],
  ['rotate_2',['rotate',['../d3/dfa/classce_1_1Transform.html#aeed00fcdcb8f6229959e8e028a7c382f',1,'ce::Transform::rotate(glm::vec3 delta)'],['../d3/dfa/classce_1_1Transform.html#aebfebeebdb1030108229ad465e0c8e89',1,'ce::Transform::rotate(float x, float y, float z)']]]
];
