var indexSectionsWithContent =
{
  0: "acglprstuwy~",
  1: "t",
  2: "c",
  3: "art",
  4: "gprstuwy~",
  5: "r",
  6: "lt",
  7: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros",
  7: "Pages"
};

