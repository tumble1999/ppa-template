var namespaces_dup =
[
    [ "ce", "d2/dd6/namespacece.html", "d2/dd6/namespacece" ]
];